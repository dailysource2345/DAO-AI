/**
 * ROFL HTTP Server for DAO AI - Minimal Version
 * Tests basic Node.js functionality in TEE
 */

const http = require('http');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const ENCLAVE_ID = 'rofl-enclave-' + crypto.randomBytes(8).toString('hex');

console.log('[ROFL] Starting server...');

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, { 
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  console.log('[ROFL] Request:', req.method, req.url);
  
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    res.end();
    return;
  }

  if (req.url === '/health' || req.url === '/health/') {
    sendJson(res, 200, { status: 'healthy', enclave_id: ENCLAVE_ID, timestamp: Date.now() });
    return;
  }

  if (req.url === '/info' || req.url === '/info/') {
    sendJson(res, 200, { app: 'daoai-rofl-app', version: '1.0.0', enclave_id: ENCLAVE_ID });
    return;
  }

  sendJson(res, 404, { error: 'Not found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('[ROFL] Server listening on 0.0.0.0:' + PORT);
  console.log('[ROFL] Enclave ID: ' + ENCLAVE_ID);
});

server.on('error', (err) => {
  console.error('[ROFL] Server error:', err);
});

process.on('uncaughtException', (err) => {
  console.error('[ROFL] Uncaught exception:', err);
});
