/**
 * ROFL HTTP Server for DAO AI - Minimal Version
 */

const http = require('http');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const ENCLAVE_ID = 'rofl-' + crypto.randomBytes(4).toString('hex');

console.log('[ROFL] === Starting DAO AI ROFL Server ===');
console.log('[ROFL] Node version:', process.version);
console.log('[ROFL] PORT:', PORT);

function sendJson(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  console.log('[ROFL] ' + req.method + ' ' + req.url);
  
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }

  if (req.url === '/health') {
    return sendJson(res, 200, { status: 'ok', enclave: ENCLAVE_ID, ts: Date.now() });
  }

  if (req.url === '/info') {
    return sendJson(res, 200, { app: 'daoai-rofl', v: '1.0', enclave: ENCLAVE_ID });
  }

  sendJson(res, 404, { error: 'not found' });
});

server.on('error', (e) => {
  console.error('[ROFL] Server error:', e.message);
  process.exit(1);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('[ROFL] === Server listening on 0.0.0.0:' + PORT + ' ===');
});
