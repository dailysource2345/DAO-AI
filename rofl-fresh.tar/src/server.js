/**
 * ROFL HTTP Server for DAO AI Confidential Identity Linking
 * 
 * This server runs inside the TEE enclave and handles:
 * - Signature verification and wallet recovery
 * - Reputation scoring computation
 * - Remote attestation generation
 */

import http from 'http';
import { processConfidentialInput, validateInput, sanitizeOutput, generateAttestation } from './main.js';
import { verifySignatureAndRecoverWallet, validateSignedInput } from './walletVerification.js';
import { getEnclaveIdentity, verifyAttestation } from './attestation.js';

const PORT = process.env.PORT || 8080;

/**
 * Parse JSON body from request
 */
async function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        resolve(JSON.parse(body));
      } catch (e) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

/**
 * Send JSON response
 */
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

/**
 * Handle requests
 */
async function handleRequest(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  try {
    // Health check endpoint
    if (url.pathname === '/health' && req.method === 'GET') {
      const enclave = getEnclaveIdentity();
      sendJson(res, 200, {
        status: 'healthy',
        mode: process.env.NODE_ENV || 'development',
        enclave: {
          enclave_id: enclave.enclave_id,
          tee_type: enclave.tee_type
        },
        timestamp: Date.now()
      });
      return;
    }

    // Main computation endpoint (confidential - no wallet address visible)
    if (url.pathname === '/compute' && req.method === 'POST') {
      const input = await parseBody(req);
      
      // Validate input has required fields
      const signedValidation = validateSignedInput(input);
      if (!signedValidation.valid) {
        sendJson(res, 400, { error: signedValidation.error });
        return;
      }

      // Step 1: Verify signature and recover wallet address INSIDE THE ENCLAVE
      const walletResult = await verifySignatureAndRecoverWallet(
        input.signed_message,
        input.challenge
      );
      
      if (!walletResult.valid) {
        sendJson(res, 400, { error: walletResult.error || 'Invalid signature' });
        return;
      }

      // Step 2: Now we have the wallet address (only visible inside enclave)
      // Create the full input for processing
      const fullInput = {
        daoai_user_id: input.daoai_user_id,
        wallet_address: walletResult.walletAddress, // Only exists inside enclave
        social_profiles: input.social_profiles
      };

      // Step 3: Validate the full input
      const validation = validateInput(fullInput);
      if (!validation.valid) {
        sendJson(res, 400, { error: validation.error });
        return;
      }

      // Step 4: Process and compute reputation score
      const result = processConfidentialInput(fullInput);
      
      // Step 5: Generate attestation
      const attestation = generateAttestation(fullInput, result);
      
      // Step 6: Sanitize output (removes wallet address before returning)
      const sanitized = sanitizeOutput(result, attestation);
      
      sendJson(res, 200, sanitized);
      return;
    }

    // Attestation verification endpoint
    if (url.pathname === '/verify-attestation' && req.method === 'POST') {
      const { attestation } = await parseBody(req);
      
      if (!attestation) {
        sendJson(res, 400, { error: 'Attestation required' });
        return;
      }

      const isValid = verifyAttestation(attestation);
      sendJson(res, 200, { valid: isValid });
      return;
    }

    // 404 for unknown routes
    sendJson(res, 404, { error: 'Not found' });
    
  } catch (error) {
    console.error('[ROFL] Request error:', error.message);
    sendJson(res, 500, { error: 'Internal server error' });
  }
}

// Create and start server
const server = http.createServer(handleRequest);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[ROFL] DAO AI Confidential Identity Server`);
  console.log(`[ROFL] Running on port ${PORT}`);
  console.log(`[ROFL] Mode: ${process.env.NODE_ENV || 'development'}`);
  console.log(`[ROFL] Enclave ready for confidential computation`);
});
