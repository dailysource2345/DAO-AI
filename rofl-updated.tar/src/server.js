/**
 * ROFL HTTP Server for DAO AI Confidential Identity Linking
 * Single entry point for the ROFL app
 */

import http from 'http';
import crypto from 'crypto';

const PORT = process.env.PORT || 8080;

// Generate a unique enclave ID for this instance
const ENCLAVE_ID = `rofl-enclave-${crypto.randomBytes(8).toString('hex')}`;

/**
 * Simple wallet signature verification using ethers
 */
async function verifySignature(signedMessage, challenge) {
  try {
    const { ethers } = await import('ethers');
    const recoveredAddress = ethers.verifyMessage(challenge, signedMessage);
    return { valid: true, walletAddress: recoveredAddress };
  } catch (error) {
    return { valid: false, error: error.message };
  }
}

/**
 * Compute reputation score from social profiles
 */
function computeReputation(socialProfiles) {
  let totalScore = 0;
  let platformCount = 0;
  const breakdown = {};

  if (socialProfiles.twitter) {
    const t = socialProfiles.twitter;
    const score = Math.min(100, 
      (t.followers || 0) * 0.01 + 
      (t.account_age_days || 0) * 0.05 + 
      (t.tweets || 0) * 0.005
    );
    breakdown.twitter = Math.round(score);
    totalScore += score;
    platformCount++;
  }

  if (socialProfiles.github) {
    const g = socialProfiles.github;
    const score = Math.min(100,
      (g.repos || 0) * 2 +
      (g.stars || 0) * 0.5 +
      (g.contributions || 0) * 0.1 +
      (g.account_age_days || 0) * 0.03
    );
    breakdown.github = Math.round(score);
    totalScore += score;
    platformCount++;
  }

  if (socialProfiles.discord) {
    const d = socialProfiles.discord;
    const score = Math.min(100,
      (d.servers || 0) * 2 +
      (d.account_age_days || 0) * 0.05 +
      (d.nitro ? 10 : 0)
    );
    breakdown.discord = Math.round(score);
    totalScore += score;
    platformCount++;
  }

  const avgScore = platformCount > 0 ? totalScore / platformCount : 0;
  const crossPlatformBonus = Math.min(20, platformCount * 5);
  const finalScore = Math.min(100, avgScore + crossPlatformBonus);
  const confidence = Math.min(100, platformCount * 25);

  return {
    reputation_score: Math.round(finalScore),
    confidence_score: Math.round(confidence),
    breakdown
  };
}

/**
 * Generate attestation for the computation
 */
function generateAttestation(input, result) {
  const timestamp = new Date().toISOString();
  const nonce = crypto.randomBytes(16).toString('hex');
  
  const outputHash = crypto.createHash('sha256')
    .update(JSON.stringify({ ...result, timestamp }))
    .digest('hex');

  const attestationHash = crypto.createHash('sha256')
    .update(`${ENCLAVE_ID}:${outputHash}:${nonce}`)
    .digest('hex');

  const signingKey = crypto.createHash('sha256')
    .update(ENCLAVE_ID + 'daoai-rofl-app')
    .digest('hex');

  const signature = crypto.createHmac('sha256', signingKey)
    .update(attestationHash)
    .digest('hex');

  return {
    version: '1.0',
    type: 'ROFL_ATTESTATION',
    enclave_id: ENCLAVE_ID,
    app_hash: 'daoai-rofl-app-v1',
    tee_type: 'TDX',
    output_hash: outputHash,
    attestation_hash: attestationHash,
    signature: { algorithm: 'HMAC-SHA256', value: signature, signer: ENCLAVE_ID },
    timestamp,
    nonce
  };
}

/**
 * Parse JSON body from request
 */
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1048576) reject(new Error('Request too large'));
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body)); }
      catch (e) { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

/**
 * Send JSON response
 */
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, { 
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(data));
}

/**
 * Request handler
 */
async function handleRequest(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.end();
    return;
  }

  try {
    // Health check
    if (url.pathname === '/health' && req.method === 'GET') {
      sendJson(res, 200, {
        status: 'healthy',
        mode: 'enclave',
        enclave_id: ENCLAVE_ID,
        timestamp: Date.now()
      });
      return;
    }

    // Info endpoint
    if (url.pathname === '/info' && req.method === 'GET') {
      sendJson(res, 200, {
        app: 'daoai-rofl-app',
        version: '1.0.0',
        enclave_id: ENCLAVE_ID,
        capabilities: ['wallet_verification', 'reputation_scoring', 'attestation']
      });
      return;
    }

    // Challenge endpoint
    if (url.pathname === '/challenge' && req.method === 'GET') {
      const challenge = `DAO AI Identity Verification\nTimestamp: ${Date.now()}\nNonce: ${crypto.randomBytes(16).toString('hex')}`;
      sendJson(res, 200, { challenge });
      return;
    }

    // Link identity endpoint (confidential)
    if (url.pathname === '/link-identity' && req.method === 'POST') {
      const input = await parseBody(req);
      
      if (!input.signed_message || !input.challenge || !input.daoai_user_id) {
        sendJson(res, 400, { error: 'Missing required fields: signed_message, challenge, daoai_user_id' });
        return;
      }

      // Verify signature and recover wallet
      const verification = await verifySignature(input.signed_message, input.challenge);
      if (!verification.valid) {
        sendJson(res, 400, { error: `Signature verification failed: ${verification.error}` });
        return;
      }

      // Compute reputation
      const reputation = computeReputation(input.social_profiles || {});
      
      // Generate attestation
      const attestation = generateAttestation(input, reputation);
      
      // Hash wallet for audit (never expose actual address)
      const walletHash = crypto.createHash('sha256')
        .update(verification.walletAddress.toLowerCase())
        .digest('hex');

      sendJson(res, 200, {
        daoai_user_id: input.daoai_user_id,
        reputation_score: reputation.reputation_score,
        confidence_score: reputation.confidence_score,
        score_breakdown: reputation.breakdown,
        wallet_hash: walletHash,
        privacy_mode: 'confidential',
        attestation
      });
      return;
    }

    // 404
    sendJson(res, 404, { error: 'Not found' });

  } catch (error) {
    console.error('[ROFL] Error:', error.message);
    sendJson(res, 500, { error: 'Internal server error' });
  }
}

// Create and start server
const server = http.createServer(handleRequest);

server.listen(PORT, '0.0.0.0', () => {
  console.log('[ROFL] DAO AI Confidential Identity Server started');
  console.log(`[ROFL] Port: ${PORT}`);
  console.log(`[ROFL] Enclave ID: ${ENCLAVE_ID}`);
});

process.on('SIGTERM', () => {
  console.log('[ROFL] Shutting down...');
  server.close(() => process.exit(0));
});
